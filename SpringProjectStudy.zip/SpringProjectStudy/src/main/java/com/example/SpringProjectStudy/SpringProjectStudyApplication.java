package com.example.SpringProjectStudy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringProjectStudyApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringProjectStudyApplication.class, args);
	}

}
